import gzip, hashlib, json, shutil
from pathlib import Path
root=Path.cwd()
out=root/'docs/evidence/reliable-experiments-validation-2026-09-30'
out.mkdir(parents=True,exist_ok=False)
runs={
'daily-short':'20260930T125125Z-reliability-daily-short-ea912d90',
'daily-long':'20260930T125244Z-reliability-daily-long-286ca6d2',
'booking-failed':'20260930T125947Z-reliability-booking-failed-b92f89bd',
'booking-coverage':'20260930T130429Z-reliability-booking-coverage-3cc2c620'}
index={'purpose':'implementation validation, not performance comparison','runs':{},'files':[]}
def save(src,dst,compressed=False):
    dst.parent.mkdir(parents=True,exist_ok=True)
    content=src.read_bytes()
    dst.write_bytes(gzip.compress(content,mtime=0) if compressed else content)
    index['files'].append({'path':dst.relative_to(out).as_posix(),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),
                           'uncompressed_sha256':hashlib.sha256(content).hexdigest()})
for name,directory in runs.items():
    run=root/'experiments/runs'/directory
    target=out/name
    completed=list(run.glob('attempts/*/*/completed.json'))
    reports=sorted(run.glob('analysis/*/summary.json'))
    summary=json.loads(reports[-1].read_text())
    assert summary['expected_cases']==summary['observed_cases']==len(completed)
    manifest=json.loads((run/'manifest.json').read_text())
    index['runs'][name]={'archive':str(run),'revision':manifest['revision'],'expected_cases':summary['expected_cases'],
                        'observed_cases':summary['observed_cases'],'complete_report':str(reports[-1].parent/'index.html'),
                        'calendar':manifest.get('booking'),'interrupted_attempts':len(list(run.glob('attempts/*/*/interrupted.json')))}
    for file in ('original-config.json','config.json','cases.json'):
        save(run/file,target/file)
    save(run/'manifest.json',target/'manifest.json.gz',True)
    for path in sorted((run/'attempts').rglob('*')):
        if path.is_file():
            relative=path.relative_to(run)
            save(path, target/(relative.as_posix()+'.gz'), True)
    for receipt in completed:
        record=json.loads(receipt.read_text())
        assert hashlib.sha256((receipt.parent/'raw.jsonl').read_bytes()).hexdigest()==record['raw_sha256']
    for file in ('summary.json','cases.csv','summary.csv','analysis-provenance.json'):
        save(reports[-1].parent/file,target/(file+'.gz'),True)
    for file in ('figure-001.png','figure-001.svg'):
        if (reports[-1].parent/file).exists(): save(reports[-1].parent/file,target/file)
for path in sorted((root/'experiments/runs/reliability-validation-gates').iterdir()):
    if path.is_file() and path.suffix in ('.log','.json','.py'):
        save(path,out/'gates'/(path.name+'.gz'),True)
(out/'index.json').write_text(json.dumps(index,indent=2)+'\n')
print(out)
print('retained bytes',sum(p.stat().st_size for p in out.rglob('*') if p.is_file()))
