import hashlib, json, os, subprocess, sys, time
from pathlib import Path
root = Path.cwd()
gates = root / 'experiments/runs/reliability-validation-gates'
before = set((root / 'experiments/runs').glob('*-reliability-booking-coverage-*'))
def hashes(folder):
    return {str(p.relative_to(folder)): hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.rglob('*') if p.is_file()}
with (gates / 'booking-coverage-first.log').open('xb') as output:
    process = subprocess.Popen([sys.executable, 'infra/experiments.py', 'run', str(gates / 'booking-coverage.json')], stdout=output, stderr=output)
    deadline = time.monotonic() + 1200
    while time.monotonic() < deadline:
        if process.poll() is not None: raise RuntimeError('Coverage process ended before interruption boundary')
        found = set((root / 'experiments/runs').glob('*-reliability-booking-coverage-*')) - before
        if len(found) == 1:
            run = found.pop()
            completed = list(run.glob('attempts/*/*/completed.json'))
            incomplete = [p.parent for p in run.glob('attempts/*/*/raw.jsonl') if not (p.parent / 'completed.json').exists()]
            if len(completed) == 1 and incomplete:
                saved = hashes(completed[0].parent)
                completed_folder = completed[0].parent
                unfinished = incomplete[0]
                process.terminate(); process.wait(timeout=20)
                time.sleep(1)
                partial = hashes(unfinished)
                print('Interrupted owned booking runner after one completed result:', run, flush=True)
                break
        time.sleep(.1)
    else:
        process.terminate(); process.wait(timeout=20)
        raise RuntimeError('Interruption boundary was not reached')
with (gates / 'booking-coverage-resume.log').open('xb') as output:
    subprocess.run([sys.executable, 'infra/experiments.py', 'resume', str(run)], stdout=output, stderr=output, check=True)
assert hashes(completed_folder) == saved
current = hashes(unfinished)
assert all(current[name] == value for name, value in partial.items())
assert (unfinished / 'interrupted.json').exists()
assert len(list(unfinished.parent.glob('*/completed.json'))) == 1
assert len(list(unfinished.parent.iterdir())) == 2
assert len(list(run.glob('attempts/*/*/completed.json'))) == 24
report = sorted(run.glob('analysis/*/summary.json'))[-1]
summary = json.loads(report.read_text())
assert summary['expected_cases'] == summary['observed_cases'] == 24
(gates / 'booking-recovery.json').write_text(json.dumps({'run': str(run), 'completed_preserved': saved, 'unfinished_preserved': partial, 'report': str(report), 'completed_cases': 24}, indent=2))
print('Booking recovery and 24-case report validated:', report, flush=True)
